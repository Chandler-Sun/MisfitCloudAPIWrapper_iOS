//
//  MisfitCloudAPIWrapper_iOS.h
//  MisfitCloudAPIWrapper_iOS
//
//  Created by ASeign on 8/11/15.
//  Copyright (c) 2015 Misfit. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MFCSession.h"
#import "MFCError.h"

//! Project version number for MisfitCloudAPIWrapper_iOS.
FOUNDATION_EXPORT double MisfitCloudAPIWrapper_iOSVersionNumber;

//! Project version string for MisfitCloudAPIWrapper_iOS.
FOUNDATION_EXPORT const unsigned char MisfitCloudAPIWrapper_iOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MisfitCloudAPIWrapper_iOS/PublicHeader.h>


