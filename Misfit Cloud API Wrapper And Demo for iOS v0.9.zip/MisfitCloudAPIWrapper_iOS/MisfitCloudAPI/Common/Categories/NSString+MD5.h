//
//  NSString+MD5.h
//  Prometheus
//
//  Created by Minh Nguyen on 4/22/13.
//  Copyright (c) 2013 Misfit Wearables. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (MD5)

- (NSString *)MD5String;

@end
